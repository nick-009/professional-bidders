
         <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
		  <li>
		   <small class="text-danger bt">&nbsp;&nbsp;&nbsp;<?php echo $lang['default']; ?> <?php echo $lang['currency']; ?> » <?php echo $currency_code; ?> (<?php echo $currency_symbol; ?>)  </small>
		  </li>
		 </ul>	