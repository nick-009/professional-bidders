<?php

/**
 * 
 */
class Table {
	
	function __construct($argument) {
		
	}
}


?>